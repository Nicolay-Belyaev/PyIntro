"""
Вызывает из контролера основную логику работы программы.
"""

import controller

controller.logic()
